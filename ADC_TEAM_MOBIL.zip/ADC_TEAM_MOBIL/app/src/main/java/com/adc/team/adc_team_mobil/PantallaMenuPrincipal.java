package com.adc.team.adc_team_mobil;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;
import android.widget.Toolbar;
import androidx.appcompat.widget.Toolbar;


public class PantallaMenuPrincipal extends AppCompatActivity {
    Button btnLogOut;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_menu_principal);

        Toolbar toolbar= findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_principal,menu);
        return super.onCreateOptionsMenu(menu);
        //return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        switch (item.getItemId()){
            case R.id.AltaIncidencia:
                Toast.makeText(this, "Nueva Alta Incidencia", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ListaIncidencia:
                Toast.makeText(this, "Lista Incidencias", Toast.LENGTH_SHORT).show();
                break;
            case R.id.BajaIncidencia:
                Toast.makeText(this, "Baja de una Incidencia", Toast.LENGTH_SHORT).show();
                break;
            case R.id.Configuracion:
                Toast.makeText(this, "Acceso a configuración", Toast.LENGTH_SHORT).show();
                break;
            case R.id.Valoracion:
                Toast.makeText(this, "Valora tu experiencia. ", Toast.LENGTH_SHORT).show();
                break;
            case R.id.Desconecta:
                Toast.makeText(this, "Desconectar.", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}