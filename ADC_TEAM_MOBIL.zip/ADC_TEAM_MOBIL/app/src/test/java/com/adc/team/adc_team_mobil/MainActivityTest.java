package com.adc.team.adc_team_mobil;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainActivityTest {

    @Test
    public void nomMetode() {
//Codificació del test
        System.out.println("Execució del test");
    }

}