package com.adc.team.adc_team_mobil;

import static org.junit.Assert.*;

public class PantallaPrincipalTest {

}